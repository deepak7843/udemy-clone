// let udlite = document.getElementById("udlite-main")


import anavbar from "./components/a_login_navbar.js"

let navbar_div = document.getElementById("container")
navbar_div.innerHTML = anavbar()